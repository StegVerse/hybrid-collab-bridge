# stegtvc_client.py
print("placeholder")